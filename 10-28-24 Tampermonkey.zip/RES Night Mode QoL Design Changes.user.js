// ==UserScript==
// @name         RES Night Mode QoL Design Changes
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Cure Summer is the best girl!
// @author       Cure Summer
// @match        *://www.old.reddit.com/*
// @grant        GM_addStyle
// @run-at            document-start
// ==/UserScript==

(function() {
  'use strict';

/* Just some Quality of Life changes for the Reddit Enhancement Suite Layout (particularly for Dark/Night Mode).*/
/* Now go watch some Precure, and let's Tropical Shine!*/
  // Change color of Progress Bar
 // GM_addStyle(' {background-color: #00f !important;}');

  // Replaces the Red Upvote and Blue Downvote Icons with Blue Upvote and Grey Downvote ones
  GM_addStyle('.res-nightmode .arrow.up, .res-nightmode .arrow.upmod, .res-nightmode .arrow.down, .res-nightmode .arrow.downmod {background-image: url(https://images2.imgbox.com/6d/36/Hh8kpHos_o.png) !important;}');

  // Replaces the Red Upvote and Blue Downvote Icons with Blue Upvote and Grey Downvote ones
  GM_addStyle('.arrow.upmod {background-image: url(https://images2.imgbox.com/84/53/yMUKKAgy_o.png) !important;}');
})();