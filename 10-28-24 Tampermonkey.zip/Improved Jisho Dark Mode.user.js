// ==UserScript==
// @name         Improved Jisho Dark Mode
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  A more aesthetic Jisho!
// @author       Cure Summer
// @match        *://www.jisho.org/*
// @grant        GM_addStyle
// @run-at       document-start
// ==/UserScript==

(function() {
  'use strict';

/* It's been a while since I've made one of these, however the Tropical Sun always shines on!*/
/* Now go watch some Precure, and let's Tropical Shine!*/

  // Change color of Highlighted Anime
  GM_addStyle('body {background-color: #101316 !important;}');
  GM_addStyle('.header.row {color: #101316 !important;}');
  GM_addStyle('.header.page {color: #101316 !important;}');
  GM_addStyle('.form.search .inner {color: #171f22 !important;}');
  GM_addStyle('.form.search .main {color: #0b0c10 !important;}');
  GM_addStyle('.form.search .search-form_clear-button {color: #1a1c27 !important;}');
  GM_addStyle('.form.search .submit {color: #1e1f28 !important;}');

  // Change color of Highlighted Anime Border
  GM_addStyle('#sidebar_today {border-color: #0259a5 !important;}');

})();