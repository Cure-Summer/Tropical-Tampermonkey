// ==UserScript==
// @name         Mangadex Dark Theme
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Beautiful Dark Mode Template!
// @author       Cure Summer
// @match        *://mangadex.org/*
// @grant        GM_addStyle
// @run-at       document-start
// ==/UserScript==

(function() {
  'use strict';

/* Just a quick Dark Mode Mod for Mangadex. I hope that you enjoy it!*/
/* Now go watch some Precure, and let's Tropical Shine!*/

  // Dark Mode
  GM_addStyle('.system {--md-background: #111 !important;}');
  GM_addStyle('.system {--md-background-translucent: #hsl(0deg 0% 10% / 60%) !important;}');
  GM_addStyle('.system {--md-background-translucent2: #hsl(0deg 0% 10% / 80%) !important;}');
  GM_addStyle('.system {--md-background-transparent: #hsl(0deg 0% 10% / 0%) !important;}');
  GM_addStyle('.system {--md-accent-lighten2: #3a3b3c !important;}');
  GM_addStyle('.system {--md-accent-lighten2: #303132 !important;}');
  GM_addStyle('.system {--md-accent: #252526 !important;}');
  GM_addStyle('.system {--md-accent-darken2: #454548 !important;}');
  //GM_addStyle('.system {--md-accent-idle: #f0f1f2 !important;}');
  GM_addStyle('.system {color: #c4c4c4 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');


  //Possibly Related Scripts
  //GM_addStyle('.system {--md-secondary: #292929 !important;}');
  //GM_addStyle('.system {--md-accent-darken: #494b4b !important;}');
  //GM_addStyle('.system {--md-shade-bright: #303132 !important;}');
  //GM_addStyle('.system {--md-shade-lessBright: #363636 !important;}');
  //GM_addStyle('.system {--md-accent-darken: #494b4b !important;}');
  //GM_addStyle('.system {--md-shade-mid: #34393e !important;}');
  //GM_addStyle('.system {--md-shade-mid-translucent: #34393e55 !important;}');
  //GM_addStyle('.system {--md-shade-mid-translucent-less: #34393e88: #f0f1f2 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');
  //GM_addStyle('.system {inserttexthere: #f0f1f2 !important;}');


// md-accent controls the search bar, genre bubbles, and other general text
// md-accent-darken2 controls the color of the "Ctrl", and "K" Bubbles, among other things.
// md-accent-idle controls the elipsis box
// color changes the color of the text on the site

})();