// ==UserScript==
// @name         FlashTV Night Mode Fix
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  I Love Pretty Cures, and you should too!
// @author       Cure Summer
// @match        *://www.old.reddit.com/r/FlashTV/*
// @grant        GM_addStyle
// @run-at            document-start
// ==/UserScript==

(function() {
  'use strict';

/* Go watch some Precure, and let's Tropical Shine!*/

/* RES Night Mode FlashTV Quality of Life Changes*/
  // Change color of the Background on the Dark Mode when using RES (Front Page)
  GM_addStyle('.res.res-nightmode #ad-frame, .res.res-nightmode #ad_main, .res.res-nightmode #ad_main_top, .res.res-nightmode #bottom-comments:not(.child)>.sitetable>.comment, .res.res-nightmode #images, .res.res-nightmode #previoussearch #moresearchinfo, .res.res-nightmode .account-activity-box, .res.res-nightmode .comments-page .link, .res.res-nightmode .linefield, .res.res-nightmode .search-result-listing+.search-result-listing .contents, .res.res-nightmode .search-result-subreddit, .res.res-nightmode .side .sidecontentbox, .res.res-nightmode .side .titlebox, .res.res-nightmode .sponsorshipbox, .res.res-nightmode .stylesheet-customize-container .pretty-form, .res.res-nightmode .submit-page .roundfield, .res.res-nightmode .wiki-page .wiki-page-content, .res.res-nightmode [class] .searchfacets, .res.res-nightmode body.listing-page>.content, .res.res-nightmode body.other-discussions-page>.content, .res.res-nightmode div.linkinfo, .res.res-nightmode .commentarea {background-color: rgb(22 22 22) !important;}');
})();